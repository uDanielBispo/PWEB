var nums = new Array(0,0,0);
var i = 0;

for (let i = 1; i <= nums.length; i++) {
    nums[i-1] = prompt('Digite o ' + i + ' numero:');    
}

function ordenar(a, b){a-b}

function maior(n){
    nums = n;
    return Math.max.apply(null, n); 
}
function crescente(n){
    return n.sort();
}

alert('O maior numero é: ' + maior(nums) + '\nO array ordenado fica: ' + nums.sort((a,b) => a - b));