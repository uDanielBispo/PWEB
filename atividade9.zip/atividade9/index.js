var totalIdade = 0;
var maisVelha = 0;
var maisNova = 0;
var totPessimo = 0;
var totPessoas = 0;
var totalMulheres = 0;
var totalHomens = 0;
var totalOtimo = 0;
var totalBom = 0;

function adicionarResposta() {
    const idade = parseInt(document.getElementById('idade').value);
    const sexo = document.getElementById('sexo').value;
    const opiniao = document.getElementById('opiniao').value;

    totalIdade += idade;
    maisVelha = Math.max(maisVelha, idade);
    maisNova = Math.min(maisNova, idade);

    totPessoas++;

    if (opiniao === 'péssimo')totPessimo++;

    if (sexo === 'Feminino') totalMulheres++;
    if (sexo === 'Masculino') totalHomens++;

    if (opiniao == 'ótimo') totalOtimo++;
    if (opiniao == 'bom') totalBom++;

    console.log(opiniao);
    

    document.getElementById('mediaIdade').textContent = (totalIdade / totPessoas).toFixed(2);
    document.getElementById('maisVelha').textContent = maisVelha;
    document.getElementById('maisNova').textContent = maisNova;
    document.getElementById('totPessimo').textContent = totPessimo;
    document.getElementById('porcentagemPessimo').textContent = ((totPessimo / totPessoas) * 100).toFixed(2) + '%';
    document.getElementById('totalOtimo').textContent = totalOtimo;
    document.getElementById('totalBom').textContent = totalBom;
    document.getElementById('totalMulheres').textContent = totalMulheres;
    document.getElementById('totalHomens').textContent = totalHomens;

    if(maisNova == 0) document.getElementById('maisNova').textContent = '';
}